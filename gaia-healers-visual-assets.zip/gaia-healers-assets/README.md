# Gaia Healers Visual Asset / Reference Pack

This pack is intended for Claude/Codex as an implementation reference for the Gaia Healers UI direction.

## Most important reference
`reference/iphone-home-concept.png`

The iPhone concept is the primary target for hierarchy and visual polish.

## Product hierarchy
For authenticated GHL/Gaia Healers members, prioritize:
1. Courses
2. Events
3. Bookings
4. Community
5. Personalized daily/member content
6. Public wellness tools

For guests, public wellness tools can remain higher because they are part of acquisition/conversion.

## Frozen area
DO NOT modify Energy Pulse measurement behavior:
- camera PPG
- DSP/signal processing
- BPM estimation
- thresholds
- filtering
- channel selection
- sampling
- sensitivity
- confidence logic
- timing/measurement flow

Presentation around Pulse may be visually polished only when isolated from measurement behavior.

## How to use the images
The generated board and crops are visual references. They are not production-perfect SVG exports.
Prefer:
- existing icon libraries already in the app;
- clean SVG/CSS recreation for simple symbols;
- optimized WebP/AVIF/PNG only for illustrative artwork.

Do not crop tiny icons out of the board and ship them as app icons.

## Desired feel
Premium, modern, sacred/cosmic, professional, restrained glassmorphism, deep navy, violet light, warm gold, occasional cyan/magenta accents. Avoid turning Gaia Healers into a generic SaaS dashboard.

## Performance
Visual implementation must not undo the performance work. Lazy-load large illustrations where appropriate, optimize raster artwork, and avoid adding another large icon font.
